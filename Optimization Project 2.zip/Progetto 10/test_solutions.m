clear
clc

pkg load statistics;

# Load the data
load dataset10.mat

# Define the types of SVMs to be used
types = {'SVM', 'SVM-DUAL'};

# Set the number of folds
folds = 10;

# Split the data into 10 folds using cvpartition function, which is part of the statistics package
# The function returns a cvpartition object, which contains the indices of the folds
folds_indices = cvpartition(y, "KFold", folds);

# Get the indices of the training and test sets for the first level
train_indices = training(folds_indices, 5);
test_indices = test(folds_indices, 5);

# Split the data into training and test sets
X_train = X(train_indices, :);
y_train = y(train_indices);
X_test = X(test_indices, :);
y_test = y(test_indices);

# Set the value of C
C = 100;

# Iterate over the types of SVMs to check the correctness of the solutions
# by checking the values of the objective function
for i = 1:length(types)

  # Get the type of SVM
  type = types{i};

  # Print the type of SVM
  disp(sprintf("########## Solving with %s ##########", type));

  # Get the solution of the SVM
  if strcmpi(type,'SVM')
    [v, gamma] = svm(X_train, y_train, C, num_iterations=10000, debug=true);
  elseif strcmpi(type,'SVM-DUAL')
    [v, gamma] = svm_dual(X_train, y_train, C, num_iterations=10000, debug=true);
  endif

  # Plot the results
  xxMin = min(X_train(:,1));
  xxMax = max(X_train(:,1));

  yyMin = min(X_train(:,2));
  yyMax = max(X_train(:,2));

  zzMin = min(X_train(:,3));
  zzMax = max(X_train(:,3));

  positive_points = X_train(y_train == 1, :);
  negative_points = X_train(y_train == -1, :);

  plot3D(positive_points, negative_points, v, gamma, xxMin, xxMax, yyMin, yyMax, zzMin, zzMax, 0, type);

endfor
