clear
clc

pkg load statistics;

# Load the data
load dataset10.mat

# Define the types of SVMs to be used
types = {'SVM', 'SVM-DUAL'};

# Select the type of SVM problem to be solved
type = types{2};

# Perform Bilevel Cross Validation
# 1. Split the data into 10 folds
# 2. For each fold, perform 5-fold cross validation (Model Selection)

# Set the number of folds
first_level_folds = 10;
second_level_folds = 5;

# Split the data into 10 folds using cvpartition function, which is part of the statistics package
# The function returns a cvpartition object, which contains the indices of the folds
first_level_indices = cvpartition(y, "KFold", first_level_folds);

# Create a vector to store the metrics for each fold
# 1. Average training correctness (Accuracy)
# 2. Average training sensitivity
# 3. Average training specificity
# 4. Average training F-score
# 5. Average testing correctness (Accuracy)
# 6. Average testing sensitivity
# 7. Average testing specificity
# 8. Average testing F-score
metrics = zeros(1,8);

# Create a vector of the possible values of C
C_values = [1, 10, 100, 1000];


for i = 1: first_level_folds

  disp(sprintf("########## First Level Fold %d ##########", i));

  # Get the indices of the training and test sets for the first level
  train_indices = training(first_level_indices, i);
  test_indices = test(first_level_indices, i);

  # Split the data into training and test sets
  X_train = X(train_indices, :);
  y_train = y(train_indices);
  X_test = X(test_indices, :);
  y_test = y(test_indices);

  # Split the training data into 5 folds
  second_level_indices = cvpartition(y_train, "KFold", second_level_folds);

  # Create a vector to store the metrics for each value of C
  C_metrics = zeros(length(C_values), 1);

  for j = 1: length(C_values)

    # Get the value of C
    C = C_values(j);

    disp(sprintf("########## C = %d ##########", C));

    for k = 1: second_level_folds

      disp(sprintf("########## Second Level Fold %d ##########", k));

      # Get the indices of the training and test sets for the second level
      train_indices = training(second_level_indices, k);
      test_indices = test(second_level_indices, k);

      # Split the data into training and test sets
      X_train_2 = X_train(train_indices, :);
      y_train_2 = y_train(train_indices);
      X_test_2 = X_train(test_indices, :);
      y_test_2 = y_train(test_indices);

      if strcmpi(type,'SVM')

        # Solve the primal problem
        [v, gamma] = svm(X_train_2, y_train_2, C);

      elseif strcmpi(type,'SVM-DUAL')

        # Solve the dual problem and recover the primal solution
        [v, gamma] = svm_dual(X_train_2, y_train_2, C);

      endif

      # Compute the predictions
      y_pred = predict(X_test_2, v, gamma);

      # Add the metrics for the current value of C
      C_metrics(j) = C_metrics(j) + correctness(y_pred, y_test_2);

      disp(sprintf("- Correctness: %f", correctness(y_pred, y_test_2)));

    endfor

    # Compute the mean of the metrics for each value of C
    C_metrics(j) = C_metrics(j) / second_level_folds;

    disp(sprintf("- Mean Correctness: %f", C_metrics(j)));

  endfor

  # Get the index of the best value of C
  [max_metric, best_C_index] = max(C_metrics);

  # Get the best value of C
  best_C = C_values(best_C_index);

  disp(sprintf("Best C: %d", best_C));

  if strcmpi(type,'SVM')

    # Solve the primal problem
    [v, gamma] = svm(X_train, y_train, C);

  elseif strcmpi(type,'SVM-DUAL')

    # Solve the dual problem and recover the primal solution
    [v, gamma] = svm_dual(X_train, y_train, C);

  endif

  # Compute the metrics for the current fold on the training set
  y_pred = predict(X_train, v, gamma);

  metrics(1) = metrics(1) + correctness(y_pred, y_train);
  metrics(2) = metrics(2) + sensitivity(y_pred, y_train);
  metrics(3) = metrics(3) + specificity(y_pred, y_train);
  metrics(4) = metrics(4) + f_score(y_pred, y_train);

  # Compute the metrics for the current fold on the test set
  y_pred = predict(X_test, v, gamma);

  metrics(5) = metrics(5) + correctness(y_pred, y_test);
  metrics(6) = metrics(6) + sensitivity(y_pred, y_test);
  metrics(7) = metrics(7) + specificity(y_pred, y_test);
  metrics(8) = metrics(8) + f_score(y_pred, y_test);

  # Plot the results
  xxMin = min(X_train(:,1));
  xxMax = max(X_train(:,1));

  yyMin = min(X_train(:,2));
  yyMax = max(X_train(:,2));

  zzMin = min(X_train(:,3));
  zzMax = max(X_train(:,3));

  positive_points = X_train(y_train == 1, :);
  negative_points = X_train(y_train == -1, :);

  plot3D(positive_points, negative_points, v, gamma, xxMin, xxMax, yyMin, yyMax, zzMin, zzMax, i, type);

endfor

# Compute the mean of the metrics for each fold
for i = 1: length(metrics)
  metrics(i) = metrics(i) / first_level_folds;
endfor

# Print the metrics
disp(sprintf("Train Correctness: %f", metrics(1)));
disp(sprintf("Train Sensitivity: %f", metrics(2)));
disp(sprintf("Train Specificity: %f", metrics(3)));
disp(sprintf("Train F-Score: %f", metrics(4)));
disp(sprintf("Test Correctness: %f", metrics(5)));
disp(sprintf("Test Sensitivity: %f", metrics(6)));
disp(sprintf("Test Specificity: %f", metrics(7)));
disp(sprintf("Test F-Score: %f", metrics(8)));
