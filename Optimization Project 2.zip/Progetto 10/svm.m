function [v, gamma] = svm(X, y, C, num_iterations = 200, debug = false)

  # Starting point
  x0 = [];

  # Number of points and dimension
  [num_points, dim] = size(X);

  # Number of variables: dim + gamma + num_points
  num_var = dim + 1 + num_points;

  # Split the points into positive and negative
  positive_points = X(y == 1, :);
  negative_points = X(y == -1, :);

  # Number of positive and negative points
  num_pos_points = size(positive_points,1);
  num_neg_points = size(negative_points,1);

  # Compute the Hessian matrix
  H = zeros(num_var, num_var);

  for i = 1: dim
    H(i, i) = 1;
  endfor

  # Compute the equality constraints
  A = [];

  # Compute the right hand side of the equality constraints
  b = [];

  # Compute the inequality constraints
  A_in = zeros(num_points,num_var);

  for i = 1: num_points

    # Coeffients for v
    A_in(i, 1:dim) = y(i) * X(i, :);

    # Coefficient for gamma
    A_in(i, dim + 1) = -y(i);

    # Coefficient for xi and psi
    A_in(i, dim + 1 + i) = 1;

  endfor

  # Lower bounds for the inequality constraints
  A_lb = ones(num_points,1);

  # Upper bounds for the inequality constraints
  A_ub = [];

  # Upper bounds for the variables
  ub = [];

  # Lower bounds for the variables
  lb = zeros(num_var,1);
  lb(1 : dim + 1) = -inf;

  # Compute the linear term
  q = zeros(num_var,1);

  for i = dim + 2: num_var
    q(i) = C;
  endfor

  # Set the number of iterations
  options = optimset("MaxIter", num_iterations);

  # Solve the quadratic program
  [xStar, fval, exitflag, output] = qp(x0, H, q, A, b, lb, ub, A_lb, A_in, A_ub, options);

  # Show the information about the solution
  if debug

    disp(sprintf("Objective function value: %f", fval));
    disp(sprintf("Maximum number of iterations: %d", num_iterations));
    disp(sprintf("Number of iterations required to find the solution: %d", exitflag.solveiter));

    keys = {0, 1, 2, 3, 6};

    values = {"The problem is feasible and convex. Global solution found.",
              "The problem is not convex. Local solution found.",
              "The problem is not convex and unbounded.",
              "Maximum number of iterations reached.",
              "The problem is infeasible."};

    map = containers.Map(keys, values);

    disp(sprintf("Status of the solution: %s", map(exitflag.info)));

  endif

  # Take vStar from xStar
  v = xStar(1 : dim)';

  # Take gammaStar from xStar
  gamma = xStar(dim + 1);

endfunction
