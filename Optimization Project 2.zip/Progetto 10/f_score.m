function value = f_score(y_pred, y_true)
  value = 2 * (sensitivity(y_pred, y_true) * precision(y_pred, y_true)) / (sensitivity(y_pred, y_true) + precision(y_pred, y_true));
endfunction