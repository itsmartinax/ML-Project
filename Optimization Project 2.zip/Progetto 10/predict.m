function y1 = predict(X, v, gamma)

    y_pred = zeros(length(X), 1);

    for i = 1:length(X)

        if v * X(i, :)' >= gamma
            y_pred(i) = 1;
        else
            y_pred(i) = -1;
        endif

    endfor

    y1 = y_pred;

endfunction
