function plot3D(positive_points, negative_points, v, gamma, x_axis_start, x_axis_end, y_axis_start, y_axis_end, z_axis_start, z_axis_end, fold, type)

clf;

axis([x_axis_start x_axis_end y_axis_start y_axis_end z_axis_start z_axis_end]);

measure = 30;

# Draw positive points
scatter3(positive_points(:,1), positive_points(:,2), positive_points(:,3), measure, 'r', 'filled');

hold on;

# Draw negative points
scatter3(negative_points(:,1), negative_points(:,2), negative_points(:,3), measure, 'b', 'filled');

hold on;

# Draw the main hyperplane H(v, gamma)
x = linspace(x_axis_start, x_axis_end, 100);
y = linspace(y_axis_start, y_axis_end, 100);
[X, Y] = meshgrid(x, y);
Z = (-v(1)*X - v(2)*Y + gamma)/v(3);
surf(X, Y, Z, 'FaceAlpha', 0.5, 'EdgeColor', 'none');

hold on;

# Draw the positive supporing hyperplane H+(v,gamma)
Z = (-v(1)*X - v(2)*Y + gamma + 1)/v(3);
surf(X, Y, Z, 'FaceAlpha', 0.5, 'EdgeColor', 'none');

hold on;

# Draw the negative supporing hyperplane H-(v,gamma)
Z = (-v(1)*X - v(2)*Y + gamma - 1)/v(3);
surf(X, Y, Z, 'FaceAlpha', 0.5, 'EdgeColor', 'none');

hold on;

if strcmpi(type,'SVM')
  path = strcat('plots/svm/fold-', num2str(fold));
elseif strcmpi(type,'SVM-DUAL')
  path = strcat('plots/svm-dual/fold-', num2str(fold));
endif

# Save the plot
print("-djpg", path);

endfunction

