function [v, gamma] = svm_dual(X, y, C, num_iterations = 200, debug = false)

  # Starting point
  x0 = [];

  # Number of points and dimension
  [num_points, dim] = size(X);

  # Number of variables
  num_var = num_points;

  # Split the points into positive and negative
  positive_points = X(y == 1, :);
  negative_points = X(y == -1, :);

  # Number of positive and negative points
  num_pos_points = size(positive_points,1);
  num_neg_points = size(negative_points,1);

  # Compute the Hessian matrix
  H = zeros(num_var, num_var);

  for i = 1: num_points
     for j = 1: num_points

      if i <= num_pos_points && j <= num_pos_points
          H(i,j) = positive_points(i,:) * positive_points(j,:)';

      elseif i > num_pos_points && j > num_pos_points
          H(i,j) = negative_points(i-num_pos_points,:) * negative_points(j-num_pos_points,:)';

      elseif i <= num_pos_points && j > num_pos_points
          H(i,j) = -2 * (positive_points(i,:) * negative_points(j-num_pos_points,:)');

      endif

    endfor
  endfor

  # Compute the linear term
  q = -ones(num_var, 1);

  # Compute the equality constraints
  A = ones(1,num_var);

  for i = num_pos_points+1: num_var
    A(i) = -1;
  endfor

  # Compute the right hand side of the equality constraints
  b = [0];

  # Compute the lower and upper bounds of the variables
  lb = zeros(1, num_var);
  ub = C * ones(1, num_var);

  # Compute the lower and upper bounds of the inequality constraints
  A_lb = [];
  A_in = [];
  A_ub = [];

  # Set the number of iterations
  options = optimset("MaxIter", num_iterations);

  # Solve the quadratic program
  [xStar, fval, exitflag, output] = qp(x0, H, q, A, b, lb, ub, A_lb, A_in, A_ub, options);

  # Show the information about the solution
  if debug

    disp(sprintf("Objective function value: %f", fval));
    disp(sprintf("Maximum number of iterations: %d", num_iterations));
    disp(sprintf("Number of iterations required to find the solution: %d", exitflag.solveiter));

    keys = {0, 1, 2, 3, 6};

    values = {"The problem is feasible and convex. Global solution found.",
              "The problem is not convex. Local solution found.",
              "The problem is not convex and unbounded.",
              "Maximum number of iterations reached.",
              "The problem is infeasible."};

    map = containers.Map(keys, values);

    disp(sprintf("Status of the solution: %s", map(exitflag.info)));

  endif

  # Compute vStar starting from the solution of the quadratic program
  vStar = (positive_points' * xStar(1:num_pos_points) - negative_points' * xStar(num_pos_points+1:num_var))';

  # Compute gammaStar starting from the solution of the quadratic program (KKT conditions)
  gammaStar = 0;

  for i = 1: num_var
    if xStar(i) > 10^-6 && xStar(i) < C - 10^-6

      if i <= num_pos_points
          gammaStar = vStar * positive_points(i,:)' - 1;
      else
          gammaStar = vStar * negative_points(i-num_pos_points,:)' + 1;
      endif

      break;

    endif
  endfor

  v = vStar;
  gamma = gammaStar;

endfunction
