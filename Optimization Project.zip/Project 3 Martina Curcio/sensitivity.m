function value = sensitivity(y_pred, y_true)
  value = sum(y_pred(y_true == 1) == y_true(y_true == 1)) / sum(y_true == 1);
endfunction