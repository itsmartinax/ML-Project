function value = correctness(y_pred, y_true)
  value = sum(y_pred == y_true) / length(y_true);
endfunction