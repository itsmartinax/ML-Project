% INPUT:
% x1 = first row vector
% x2 = second row vector
% sigma = scalar parameter
% OUTPUT:
% gk = Gaussian Kernel K(x1,x2) = exp(-||x1-x2||^2 / 2*sigma)

function gk = GaussianKernel(x1, x2, sigma)
  gk = exp(-(x1*x1'+x2*x2'-2*x1*x2')/(2*sigma));
endfunction
