function value = precision(y_pred, y_true)
    value = sum(y_pred(y_true == 1) == y_true(y_true == 1)) / sum(y_pred == 1);
end