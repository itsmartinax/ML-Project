function y1 = GaussianPredict(X, x0, R, sigma)

    y_pred = zeros(length(X), 1);

    for i = 1:length(X)

        if 2*(1-GaussianKernel(x0, X(i,:), sigma)) <= R^2
            y_pred(i) = 1;
        else
            y_pred(i) = -1;
        endif

    endfor
    y1 = y_pred;
endfunction
