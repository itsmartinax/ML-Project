function [x0,R] = GaussianSphericalSeparation(X,y,C,sigma)

% Number of points and variables
[num_points, dim]=size(X);
num_var = num_points+1;

% Split the points into positive and negative
pos_points = X(y == 1, :);
neg_points = X(y == -1, :);

% Number of positive and negative points
num_pospoints = size(pos_points,1);
num_negpoints = size(neg_points,1);

% Compute the center of the sphere as the barycenter of the positive points
x0 = sum(pos_points)/num_pospoints;

% Column array containing the objective function coefficients
c = [1; C*ones(num_points,1)];

% Matrix containing the constraints coefficients
for i=1:num_points
  A(i,1)=y(i);
  A(i,i+1)=1;
 endfor

% Column array containing the right-hand side value for each constraint in the
% constraint matrix
 for i=1:num_points
   b(i)=2*y(i)*(1-GaussianKernel(x0, X(i,:), sigma));
 endfor
 b = b';

% Array containing the lower bound on each of the variables
lb = zeros(num_var,1);

% Array containing the upper bound on each of the variables
ub = inf(num_var,1);

% Array of characters containing the sense of each constraint
% in the constraint matrix
ctype="";
for i=1:num_points
  ctype=[ctype, "L"];
endfor

% Column array containing the types of the variables
vartype="";
for i=1:num_var
  vartype=[vartype, "C"];
endfor
vartype=vartype';

% Sense: 1 for minimization, -1 for maximization
sense = 1;

% Solve the problem
% options = optimset("itlim",10000)
[xStar, obStar] = glpk(c, A, b, lb, ub, ctype, vartype, sense);

z = xStar(1);
R = sqrt(z);
